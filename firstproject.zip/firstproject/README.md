# APND-Adnroid-mini-project
Implementation of different features of android studio 

Rename The main File to first project

